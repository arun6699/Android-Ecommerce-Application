package com.example.arun_raju_project1;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Check_out  extends AppCompatActivity {


    Button submitButton;
    EditText Custname;
    EditText Custemail;
    EditText Custcvv;
    EditText  CustcardDet;
    RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_out);


        Custname = findViewById(R.id.Cname);
        Custemail = findViewById(R.id.Cemail);
        CustcardDet = findViewById(R.id.cardDet);
        Custcvv = findViewById(R.id.cvv);



        TextView productTextView = (TextView) findViewById(R.id.txtName);
        productTextView.setText(getIntent().getExtras().getString("productName"));


        TextView productPrice = (TextView) findViewById(R.id.txtPrice);
        productPrice.setText(getIntent().getExtras().getString("productPrice"));


        submitButton = (Button) findViewById(R.id.Submit);
        submitButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {

                String name =  Custname.getText().toString().trim();
                String email =  Custemail.getText().toString().trim();
                String card =  CustcardDet.getText().toString().trim();
                String cvvDet =  Custcvv.getText().toString().trim();

                // validatinh inputs.
                if(name.isEmpty() || email.isEmpty()) {
                    Toast.makeText(Check_out.this,"Please enter Name and Email", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(card.isEmpty() || cvvDet.isEmpty()) {
                    Toast.makeText(Check_out.this," Please enter payment Details", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Alert box showing message.
                new AlertDialog.Builder(Check_out.this)
                        .setTitle("Thank you")
                        .setMessage("Your order has been placed")
                        .setNeutralButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent intent = new Intent(Check_out.this, MainActivity.class);
                                startActivity(intent);
                            }
                        }).create().show();
            }
        });
    }

}
