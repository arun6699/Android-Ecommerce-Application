package com.example.arun_raju_project1;

public class ProductModel {
    private int image;
    private String name;
    private double cost;
    private String desc;


    public ProductModel(int image, String name, String desc, double cost) {
        this.image = image;
        this.name = name;
        this.cost = cost;
        this.desc = desc;
    }

    public int getmimage() {
        return image;
    }

    public void setimage(int mImageDrawable) {
        this.image = image;
    }

    public String getname() {
        return name;
    }

    public void setname(String mName) {
        this.name = name;
    }

    public String getdesc() {
        return desc;
    }

    public void setdesc(String mDescription) {
        this.desc = desc;
    }

    public double getcost() {
        return cost;
    }

    public void setcost(double mPrice) {
        this.cost = cost;
    }
}
