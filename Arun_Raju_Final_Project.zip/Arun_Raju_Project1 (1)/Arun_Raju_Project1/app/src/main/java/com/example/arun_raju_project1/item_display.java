package com.example.arun_raju_project1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class item_display  extends AppCompatActivity {

    private TextView myProductDescription;
    private TextView myProductName;
    private TextView myPrice;
    private ImageView myImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_display);

        myProductDescription = findViewById(R.id.product_description);
        myProductName = findViewById(R.id.product_name);
        myImage = findViewById(R.id.product_image);
        myPrice = findViewById(R.id.product_price);

        final Intent intent = getIntent();
        int index = intent.getIntExtra("ID", 0);
        ProductModel product = MainActivity.itemarray.get(index);

        myProductDescription.setText(product.getdesc());
        myProductName.setText(product.getname());
        myPrice.setText(String.valueOf(product.getcost()) + "$");
        myImage.setImageResource(product.getmimage());


        TextView textView = (TextView) findViewById(R.id.text_action_bottom1);
        textView.setOnClickListener(new View.OnClickListener() {

            // sending the product to the cart page
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(item_display.this, Check_out.class);
                intent1.putExtra("productName", myProductName.getText().toString());
                intent1.putExtra("productPrice", myPrice.getText().toString());
                startActivity(intent1);
            }
        });
    }
}
