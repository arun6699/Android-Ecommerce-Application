package com.example.arun_raju_project1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    int[] images;
    public static ArrayList<ProductModel> itemarray = new ArrayList<>();

    Button btnGoStore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnGoStore = findViewById(R.id.btnGoStore);


        itemarray.add(new ProductModel(R.drawable.mobile6, "I PHONE XS", "Super Retina in two sizes — including the largest display ever on an iPhone. Even faster Face ID. The smartest, most powerful chip in a smartphone. And a breakthrough dual‑camera system with Depth Control. iPhone XS is everything you love about iPhone. Taken to the extreme.", 1200));
        itemarray.add(new ProductModel(R.drawable.mobile2, "PIXEL 3XL", "Meet the Google Pixel 3 XL. Capture the perfect shot every time, get things done with the Google Assistant, enjoy a long-lasting battery, and more.", 1000));
        itemarray.add(new ProductModel(R.drawable.mobile7, "IPHONE XR", "Brilliant. In every way. All-new Liquid Retina display — the most advanced LCD in the industry. Even faster Face ID. The smartest, most powerful chip in a smartphone. And a breakthrough camera system. iPhone XR. It’s beautiful any way you look at it.", 1000));
        itemarray.add(new ProductModel(R.drawable.mobile8, "IHONE X", "One so immersive the device itself disappears into the experience. And so intelligent it can respond to a tap, your voice and even a glance. With iPhone X, that vision is now a reality. Say hello to the future.", 950));
        itemarray.add(new ProductModel(R.drawable.mobile5, "IPHONE XS MAX", "Super retina in two sizes - including the largest display ever on an iPhone. Even faster Face ID. The smartest, most powerful chip in a smartphone. And a breakthrough dual-camera system. iPhone Xs is everything you love about iPhone. Taken to the extreme." , 1299));

        images = new int[] { R.drawable.mobile1,
                R.drawable.mobile2,
                R.drawable.mobile3,
                R.drawable.mobile4,
                R.drawable.mobile5,
                R.drawable.mobile6,
                R.drawable.mobile7,
                R.drawable.mobile8};

        btnGoStore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent MyIntent = new Intent(MainActivity.this, list.class);
                startActivity(MyIntent);
            }
        });
    }
}
