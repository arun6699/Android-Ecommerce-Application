package com.example.arun_raju_project1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class list  extends AppCompatActivity {

    ListView listvw;
    ProductAdapter proadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);


        listvw = findViewById(R.id.lView);

        proadapter = new ProductAdapter(this, MainActivity.itemarray);
        listvw.setAdapter(proadapter);

        listvw.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(list.this, item_display.class);
                intent.putExtra("ID", position);
                startActivity(intent);
            }
        });


    }
}
